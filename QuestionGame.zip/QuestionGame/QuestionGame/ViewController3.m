//
//  ViewController3.m
//  QuestionGame
//
//  Created by Olawale Jaiyeola on 7/4/16.
//  Copyright (c) 2016 Olawale Jaiyeola. All rights reserved.
//

#import "ViewController3.h"

@interface ViewController3 ()

@end

@implementation ViewController3
@synthesize textView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (BOOL) textFieldShouldReturn:(UITextField *)textField
{
    NSLog(@"Want to send question to server: %@", textField.text);
    //NSString *uniqueIdentifier = [device uniqueIdentifier];
    
    return [self prepareAndSendInformation:textField];
}

- (BOOL) prepareAndSendInformation:(UITextField *)textField
{
    
    //check if question field is filled
    NSString *question = [[NSString alloc] init];
    question = [self getQuestionFromField];
    
    if(question.length == 0)
    {
        return FALSE;
    }
    
    
    //Create containers for tokens and their values
    NSMutableDictionary* tokens = [[NSMutableDictionary alloc] initWithCapacity:10];
    NSMutableDictionary* tokens_yes = [[NSMutableDictionary alloc] initWithCapacity:10];
    NSMutableDictionary* tokens_no = [[NSMutableDictionary alloc] initWithCapacity:10];
    
    
    //check entered tokens for errors
    [self getTokensAndTheirValues:tokens :tokens_yes :tokens_no];
    if (![self checkTokensValid:tokens :tokens_yes :tokens_no])
    {
        textView.text = @"Please enter valid tokens and values";
        return FALSE;
    }
    
    
    //Prepare relevant data for tranmission
    NSURL* url = [NSURL URLWithString:[MainAddress defaultAddress]];
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setPostValue:@"111" forKey:@"app_id"];
    [request setPostValue:@"1" forKey:@"question_id"];
    [request setPostValue:question forKey:@"new_question"];
    [self insertTokensIntoRequest:request :tokens :tokens_yes :tokens_no];
    [request setDelegate:self];
    [request startAsynchronous];
    
    
    //Hide keyword
    [textField resignFirstResponder];
    
    //clear text field
    textField.text = @"";
    
    
    //let the user know you are going to get info from database
   // MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
   // hud.label.text = @"Retrive...";
   // [MBProgressHUD hideHUDForView:self.view animated:YES];
    
    return TRUE;
}//prepareAndSendInformation

-(void)requestFinished:(ASIHTTPRequest *)request
{
    if(request.responseStatusCode == 400)
    {
        textView.text = @"Invalid Id";
    }
    else if (request.responseStatusCode == 403)
    {
        textView.text = @"This is forbidden";
    }
    else if(request.responseStatusCode == 200)
    {
        NSString *responseString = [request responseString];
        NSDictionary *responseDict = [responseString JSONValue];
         NSArray *responseArray = [NSJSONSerialization JSONObjectWithData:[request responseData] options:0 error:nil];
        NSString *result = [responseDict objectForKey:@"tokens"];
        NSArray* responseKeys = [responseDict allKeys];
        if(responseKeys.count > 0)
        {
            textView.text = [responseDict objectForKey:[responseKeys objectAtIndex:0]];
            if(targetVC)
            {
                targetVC.responseLabel.text = textView.text;
            }
        }
        NSLog(@"Got some data");
    }
    else
    {
        textView.text = @"Unexpected error";
        if(targetVC)
        {
            targetVC.responseLabel.text = textView.text;
        }
    }
}


- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSError *error = [request error];
    textView.text = error.localizedDescription;
    targetVC.responseLabel.text = textView.text;
}

- (IBAction)sendData:(id)sender
{
    NSLog(@"here is %@", targetVC.userText.text);
    [self prepareAndSendInformation:nil];
    targetVC.responseLabel.text = textView.text;
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
        targetVC = [segue destinationViewController];
    
        if([[segue destinationViewController] isKindOfClass:[ViewController4 class]])
        {
            targetVC.userText = textView;
        }
}

- (BOOL) checkTokensValid:(NSMutableDictionary*) tokens : (NSMutableDictionary*) tokens_yes : (NSMutableDictionary*) tokens_no
{
    if (tokens.count == 0)
    {
        return FALSE;
    }
    
    //if arrays of tokens, yes_values, no_values differ in size, then some information must be missing
    if((tokens.count == tokens_yes.count) && (tokens.count == tokens_no.count))
    {
        NSArray* tokenKeys = [tokens allKeys];
        NSArray* yesKeys = [tokens_yes allKeys];
        NSArray* noKeys = [tokens_no allKeys];
        if([tokenKeys isEqualToArray:yesKeys] && [tokenKeys isEqualToArray:noKeys])
        {
            
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }
    else
    {
        return FALSE;
    }
}

- (void) insertTokensIntoRequest: (ASIFormDataRequest*) request :(NSMutableDictionary*) tokens : (NSMutableDictionary*) tokens_yes : (NSMutableDictionary*) tokens_no
{
    for (int i = 0; i < (tokens.count); i++)
    {
        
        NSString* key = [[NSString alloc] initWithFormat:@"%d",i+1];
        
        
        //copy value for _POST
        NSString* valueStringToken = [NSString stringWithString:[tokens valueForKey:key]];
        NSString* valueStringYesValue = [NSString stringWithString:[tokens_yes valueForKey:key]];
        NSString* valueStringNoValue = [NSString stringWithString:[tokens_no  valueForKey:key]];
        
        //copy keys for _POST
        NSString* keyStringToken = [ NSString stringWithFormat:@"token_description%d",i];
        NSString* keyStringYesValue = [ NSString stringWithFormat:@"token_yes_value%d",i];
        NSString* keyStringNoValue = [ NSString stringWithFormat:@"token_no_value%d",i];
        
        //set values for _POST .. .. tokens
        [request setPostValue:valueStringToken forKey:keyStringToken];
        [request setPostValue:valueStringYesValue forKey:keyStringYesValue];
        [request setPostValue:valueStringNoValue forKey:keyStringNoValue];
    }
}


- (BOOL) getTokensAndTheirValues:(NSMutableDictionary*) tokens : (NSMutableDictionary*) tokens_yes : (NSMutableDictionary*) tokens_no
{
    
    //copy tokens and values into dictionaries using keywords "Token", "Pts Y", and "Pts N"
    //to identify them
    for (UIView *i in self.view.subviews)
    {
        //get tokens and values by identifying each textfield with keywords "Token", "Pts Y", and "Pts N"
        //these are stored in the placeholder variable of the UITextFields
        if([i isKindOfClass:[UITextField class]])
        {
            NSRange stringTokenRange = NSMakeRange(0, 5);
            NSRange stringPointsRange = NSMakeRange(0, 5);
            if(([[(UITextField*)i placeholder] compare:@"Token" options:NSCaseInsensitiveSearch range:stringTokenRange] == NSOrderedSame)
               &&   ([(UITextField*)i text].length > 0))
            {
                NSString* placeHolderContent = [ [NSString alloc] initWithString:[(UITextField*)i placeholder]];
                NSString* identity = [placeHolderContent stringByTrimmingCharactersInSet:[[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
                
                [tokens setObject:[(UITextField*)i text] forKey:identity];
                
                
            }
            if(([[(UITextField*)i placeholder] compare:@"Pts Y" options:NSCaseInsensitiveSearch range:stringPointsRange] == NSOrderedSame)
               &&   ([(UITextField*)i text].length > 0))
            {
                NSString* placeHolderContent = [ [NSString alloc] initWithString:[(UITextField*)i placeholder]];
                NSString* identity = [placeHolderContent stringByTrimmingCharactersInSet:[[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
                
                [tokens_yes setObject:[(UITextField*)i text] forKey:identity];
            }
            
            if(([[(UITextField*)i placeholder] compare:@"Pts N" options:NSCaseInsensitiveSearch range:stringPointsRange] == NSOrderedSame)
               &&   ([(UITextField*)i text].length > 0))
            {
                NSString* placeHolderContent = [ [NSString alloc] initWithString:[(UITextField*)i placeholder]];
                NSString* identity = [placeHolderContent stringByTrimmingCharactersInSet:[[NSCharacterSet decimalDigitCharacterSet] invertedSet]];
                
                [tokens_no setObject:[(UITextField*)i text] forKey:identity];
            }
        }
    }
    
    
    //check if all tokens have values
    
    return TRUE;
}

- (NSString*) getQuestionFromField
{
    for (UIView *i in self.view.subviews)
    {
        if([i isKindOfClass:[UITextField class]])
        {
            NSRange stringQuestionRange = NSMakeRange(0, 8);
            if(([[(UITextField*)i placeholder] compare:@"Question" options:NSCaseInsensitiveSearch range:stringQuestionRange] == NSOrderedSame)
               &&   ([(UITextField*)i text].length > 0))
            {
                return  [(UITextField*)i text];
                
            }
        }
    }
    return nil;
}


- (void)dealloc {
    [textView release];
    [super dealloc];
}

@end
