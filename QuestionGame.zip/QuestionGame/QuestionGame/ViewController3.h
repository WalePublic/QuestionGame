//
//  ViewController3.h
//  QuestionGame
//
//  Created by Olawale Jaiyeola on 7/4/16.
//  Copyright (c) 2016 Olawale Jaiyeola. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import "SBJSON.h"
#import "MBProgressHUD.h"
#import "ViewController4.h"
#import "MainAddress.h"



@interface ViewController3 : UIViewController <UITextFieldDelegate>
{
    ViewController4 *targetVC;
}

@property (retain, nonatomic) IBOutlet UITextView *textView;
- (IBAction)sendData:(id)sender;

@end
