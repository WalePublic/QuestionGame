//
//  ViewController.h
//  QuestionGame
//
//  Created by Olawale Jaiyeola on 6/6/16.
//  Copyright (c) 2016 Olawale Jaiyeola. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"
#import "SBJSON.h"
#import "MBProgressHUD.h"
#import "ViewController2.h"
#import "MainAddress.h"
#define TOKENDEFAULTVALUE 30

@interface ViewController : UIViewController<UITextViewDelegate>
{
    ViewController2 *targetVC;
    NSMutableDictionary* myQuestionTokens;
    NSMutableDictionary* questionsAndTokensDict;
}


@property (strong, nonatomic) IBOutlet UITextView *textView;
@property(nonatomic, strong) NSMutableDictionary* myQuestionTokens;
@property(nonatomic, strong) NSMutableDictionary* questionsAndTokensDict;

- (IBAction)startButton:(id)sender;
@end

