//
//  MainAddress.h
//  QuestionGame
//
//  Created by Olawale Jaiyeola on 7/11/16.
//  Copyright © 2016 Olawale Jaiyeola. All rights reserved.
//

#ifndef MainAddress_h
#define MainAddress_h
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface MainAddress : NSObject
{
    
}
+ (NSString*)defaultAddress;
+ (void)setDefaultAddress:(NSString*) newAddress;

@end

#endif /* MainAddress_h */
