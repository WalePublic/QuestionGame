//
//  ViewController2.h
//  QuestionGame
//
//  Created by Olawale Jaiyeola on 7/3/16.
//  Copyright (c) 2016 Olawale Jaiyeola. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController5.h"

@interface ViewController2 : UIViewController<ViewController2Delegate>
{
    UITextView *userText;
    NSMutableDictionary* myQuestionTokens;
    NSMutableDictionary* questionsAndTokensDict;
    NSString* currentQuestion;
    NSString* noQuestionMessage;
    ViewController5* targetVC;
}
@property (retain, nonatomic) IBOutlet UILabel *responseLabel;

@property (retain, nonatomic) IBOutlet UITextView *userText;
@property (retain, nonatomic) IBOutlet UITextView *questionText;
- (IBAction)YesPressed:(id)sender;
- (IBAction)noPressed:(id)sender;

@property (retain, strong) NSMutableDictionary* myQuestionTokens;
@property (retain, strong) NSMutableDictionary* questionsAndTokensDict;
@property (retain, strong) NSString* currentQuestion;

@end
