//
//  AppDelegate.h
//  QuestionGame
//
//  Created by Olawale Jaiyeola on 6/6/16.
//  Copyright (c) 2016 Olawale Jaiyeola. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

