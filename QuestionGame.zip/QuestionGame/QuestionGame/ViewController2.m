//
//  ViewController2.m
//  QuestionGame
//
//  Created by Olawale Jaiyeola on 7/3/16.
//  Copyright (c) 2016 Olawale Jaiyeola. All rights reserved.
//

#import "ViewController2.h"

@interface ViewController2 ()

@end

@implementation ViewController2
@synthesize responseLabel, questionText, userText, myQuestionTokens, questionsAndTokensDict, currentQuestion;

- (void)viewDidLoad {
    
    //set a default message which will be use when user answers all questions
    if(!noQuestionMessage)
    {
        noQuestionMessage = [[NSString alloc] initWithFormat:@"No more questions"];
    }
    
    questionText.text = currentQuestion;
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    targetVC = [segue destinationViewController];
    
    
    //pass questions, tokens and current question on to the next viewcontroller as this viewcontroller
    //will be deleted to conserve memory. (along with its members).
    if([targetVC isKindOfClass:[ViewController5 class]])
    {
        targetVC.myQuestionTokens = self.myQuestionTokens;
        targetVC.currentQuestion = self.currentQuestion;
        targetVC.questionsAndTokensDict = self.questionsAndTokensDict;
    }
}

-(void)addQuestionViewController:(ViewController2 *)controller didFinishEnteringItem:(NSString *)item
{
    //current question is passed from a viewcontroller that is about to be deleted to this viewcontroller
    //that will be show to user
    currentQuestion = item;
    
    NSArray* keys = [questionsAndTokensDict allKeys];
    NSUInteger indexOfQuestion = [keys indexOfObject:currentQuestion];
    if(!noQuestionMessage)
    {
        noQuestionMessage = [[NSString alloc] initWithFormat:@"No more questions"];
    }
    
    //select next question in the array. If there is none left. Assign to default no question left message
    if(indexOfQuestion != NSNotFound)
    {
        indexOfQuestion++;
        if(indexOfQuestion < keys.count)
        {
            currentQuestion = [keys objectAtIndex:indexOfQuestion];
        }
        else
        {
            currentQuestion = [NSString stringWithString:noQuestionMessage];
        }
    }
    
    questionText.text = currentQuestion;
}

-(void)addDictionaryViewController:(ViewController2 *)controller didFinishEnteringItem:(NSMutableDictionary*)item
{
    //current token dictionary is passed from a viewcontroller that is about to be deleted to this viewcontroller
    //that will be show to user
    myQuestionTokens = item;
}

-(void)addQuestionAndTokenViewController:(ViewController2 *)controller didFinishEnteringItem:(NSMutableDictionary*)item
{
    //questions and tokens(include yes and no values) dictionary is passed from a viewcontroller that is about to be deleted to this viewcontroller
    //that will be show to user
    questionsAndTokensDict = item;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)dealloc {
    [responseLabel release];
    [questionText release];
    [noQuestionMessage release];
    [super dealloc];
}

-(void) updateQuestionsAndTokens: (bool) yesButton
{
    //get the tokens affected by user selection (either YES or NO answer)
    NSArray* affectedTokens = [questionsAndTokensDict objectForKey:currentQuestion];
    unsigned int token_descript = 0;
    unsigned int token_YesOrNo_string = 1;
    NSUInteger count = ((NSMutableArray*)[affectedTokens objectAtIndex:token_descript]).count;
    
    
    //if yes choose the appropriate array in the multi-dimensional array
    if(!yesButton)
    {
        token_YesOrNo_string = 2;
    }
    
    for(int i = 0; i < count;i++)
    {
        //make sure a selection of a item is the dictionary is of class NSString
        if([[(NSMutableArray*)[affectedTokens objectAtIndex:token_descript] objectAtIndex:i]  isKindOfClass:[NSString class]])
        {
            NSString* token_description_string = [(NSMutableArray*)[affectedTokens objectAtIndex:token_descript] objectAtIndex:i];
            NSString* yesOrNo_value_string;
            int yesOrNo_value_int = 0;
            int token_current_value = 0;
            
            
            //extract an integer for NSString string
            if(i < ((NSMutableArray*)[affectedTokens objectAtIndex:token_YesOrNo_string]).count)
            {
                
                yesOrNo_value_string =  [(NSMutableArray*)[affectedTokens objectAtIndex:token_YesOrNo_string] objectAtIndex:i];
                NSScanner* scanner = [NSScanner scannerWithString:yesOrNo_value_string];
                [scanner scanInt:&yesOrNo_value_int];
            }
            
            
            //if this is a completely new token from database then add it to dictionary
            //if not new then simply update the value in the dictionary
            if([myQuestionTokens objectForKey:token_description_string])
            {
                NSScanner* scanner = [NSScanner scannerWithString:[myQuestionTokens objectForKey:token_description_string]];
                [scanner scanInt:&token_current_value];
                NSInteger newValue = (token_current_value + yesOrNo_value_int);
                NSString* newValueString = [NSString stringWithFormat:@"%ld",(long)newValue];
                
                //replace current value by removing old value/key and then adding new value/key
                [myQuestionTokens removeObjectForKey:token_description_string];
                [myQuestionTokens setObject:newValueString forKey:token_description_string];
            }
            else
            {
                NSInteger newValue = (30 + yesOrNo_value_int);
                NSString* newValueString = [NSString stringWithFormat:@"%ld",(long)newValue];
                [myQuestionTokens setObject:newValueString forKey:token_description_string];
            }
            
        }
    }
}//updateQuestionsAndTokens
- (IBAction)YesPressed:(id)sender {
    //if there are still questions left to be answered. then update the current token value
    //by adding the points for selecting YES
    if(currentQuestion && ([currentQuestion caseInsensitiveCompare:noQuestionMessage] != NSOrderedSame))
    {
        [self updateQuestionsAndTokens:true];
    }
    targetVC.myQuestionTokens = self.myQuestionTokens;
    
}

- (IBAction)noPressed:(id)sender {
    //if there are still questions left to be answered. then update the current token value
    //by adding the points for selecting NO
    if(currentQuestion && ([currentQuestion caseInsensitiveCompare:noQuestionMessage] != NSOrderedSame))
    {
        [self updateQuestionsAndTokens:false];
    }
    targetVC.myQuestionTokens = self.myQuestionTokens;
}
@end
