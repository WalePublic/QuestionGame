//
//  ViewController5.m
//  QuestionGame
//
//  Created by Olawale Jaiyeola on 7/8/16.
//  Copyright (c) 2016 Olawale Jaiyeola. All rights reserved.
//

#import "ViewController5.h"

@interface ViewController5 ()

@end

@implementation ViewController5
@synthesize myQuestionTokens, currentQuestion, questionsAndTokensDict;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (NSInteger) numberOfSectionsInTbleView: (UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView*) tableView numberOfRowsInSection:(NSInteger)section
{
    return myQuestionTokens.count;
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    [[UILabel appearanceWhenContainedIn:[UITableViewHeaderFooterView class], nil] setTextAlignment:NSTextAlignmentCenter];
    return @"Tokens";
}

-(UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //reuse cell which will be used to fill with table with data
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"mainCell"];
    
    if(cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"mainCell"];
    }

    
    NSArray* keys = [myQuestionTokens allKeys];
    
    
    //insert token and current values in table row
    if(indexPath.row < keys.count)
    {
        NSString* keyString ;
        keyString = [keys objectAtIndex:indexPath.row];
        NSString* valueString;
        valueString =[myQuestionTokens objectForKey:keyString];
        NSString *cellContent = [[NSString alloc] initWithFormat:@"%@ %@", keyString, valueString];
        cell.textLabel.text = cellContent;
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        
        [cellContent release];
    }
    
    
    
    return cell;
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    targetVC = [segue destinationViewController];
    self.delegate = targetVC;
    
    //since this viewcontroller is about to be deleted. Pass on questions,tokens, and value
    //to the viewcontroller coming up
    [self.delegate addQuestionAndTokenViewController:self didFinishEnteringItem:questionsAndTokensDict];
    [self.delegate addDictionaryViewController:self didFinishEnteringItem:self.myQuestionTokens];
    [self.delegate addQuestionViewController:self didFinishEnteringItem:currentQuestion];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)dealloc {
    [_textTableView release];
    [super dealloc];
}
@end
