//
//  ViewController4.h
//  QuestionGame
//
//  Created by Olawale Jaiyeola on 7/5/16.
//  Copyright (c) 2016 Olawale Jaiyeola. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController4 : UIViewController
{
    UITextView *userText;
}

@property (retain, nonatomic) IBOutlet UILabel *responseLabel;
@property (retain, nonatomic) IBOutlet UITextView *userText;
@end
