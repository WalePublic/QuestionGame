//
//  ViewController.m
//  QuestionGame
//
//  Created by Olawale Jaiyeola on 6/6/16.
//  Copyright (c) 2016 Olawale Jaiyeola. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize textView, myQuestionTokens, questionsAndTokensDict;

- (void)viewDidLoad {
    
    //Load default tokens and their values
    myQuestionTokens = [[NSMutableDictionary alloc] initWithCapacity:8];
    NSMutableArray* tokenArray = [[NSMutableArray alloc] initWithObjects:@"income tax", @"education level", @"public health", @"entrepreneurship", @"community art", @"immigration", nil];
    NSInteger defaultValue = TOKENDEFAULTVALUE;
    
    for (unsigned int i = 0; i < tokenArray.count; i++)
    {
        NSUInteger index = i;
        NSString* myString = [[NSString alloc] initWithFormat:@"%ld",(long)defaultValue];
        [myQuestionTokens setObject:myString forKey:[tokenArray objectAtIndex:index] ];
    }
    
    
    //continue
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)textFieldShouldReturn:(UITextView *)textView {
    
    return TRUE;
}

- (BOOL) prepareAndSendInformation:(UITextField *)textField
{
    //Start Request
    NSString *address = [[NSString alloc] init];
    address = [self getAddressFromField];
    NSURL* url;
    
    //Check if the address field contains information, if not use default address
    if(!address && address.length == 0)
    {
        url = [NSURL URLWithString:[MainAddress defaultAddress]];
        
    }
    else
    {
        url = [NSURL URLWithString:address];
        [MainAddress setDefaultAddress:address];
    }
    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:url];
    [request setPostValue:@"111" forKey:@"app_id"];
    [request setPostValue:@"1" forKey:@"question_id"];
    [request setPostValue:nil forKey:@"question"];
    [request setDelegate:self];
    [request startAsynchronous];
    
    //Hide keyword
    [textField resignFirstResponder];
    
    //clear text field
    textField.text = @"";
    return TRUE;
}//prepareAndSendInformation

-(void)requestFinished:(ASIHTTPRequest *)request
{
    if(request.responseStatusCode == 400)
    {
        textView.text = @"Invalid Id";
    }
    else if (request.responseStatusCode == 403)
    {
        textView.text = @"This is forbidden";
    }
    else if(request.responseStatusCode == 200)
    {
        //get response and place array
        NSString *responseString = [request responseString];
        NSArray *responseArray = [NSJSONSerialization JSONObjectWithData:[request responseData] options:0 error:nil];
       questionsAndTokensDict = [NSMutableDictionary dictionary];
        NSMutableString *currentQuestion  = [NSMutableString stringWithFormat:@"None"];
        
        //if the file can not be located inform user
        if(!responseArray && targetVC)
        {
            targetVC.responseLabel.text = @"Question retrieval failed";
        }
    
        [self saveRetrievedDataIntoContainers:responseArray];
        
        //get first question and set it as the current question
        if(questionsAndTokensDict && (questionsAndTokensDict.count>0))
        {
            NSArray* keysArray = [questionsAndTokensDict allKeys];
            currentQuestion = [keysArray objectAtIndex:0];
        }
        
        //pass questions and tokens on to the next viewcontroller as this viewcontroller
        //will be deleted to conserve memory. (along with its members).
        targetVC.questionsAndTokensDict = self.questionsAndTokensDict;
        targetVC.questionText.text = currentQuestion;
        targetVC.currentQuestion = currentQuestion;
        NSLog(@"Got some data");
    }
    else
    {
        textView.text = @"Unexpected error";
    }
}


- (void)requestFailed:(ASIHTTPRequest *)request
{
    NSError *error = [request error];
    textView.text = error.localizedDescription;
    targetVC.responseLabel.text = textView.text;
}

- (void) saveRetrievedDataIntoContainers: (NSArray*)retrievedDataArray
{
    for(int i = 0; i < retrievedDataArray.count;i++)
    {
        NSString* questionRetrieved;
        NSArray* splitStrings;
        NSArray* tokenAndValuesArray = [NSArray arrayWithObjects:[NSMutableArray array], [NSMutableArray array], [NSMutableArray array], nil];
        if([[retrievedDataArray objectAtIndex:i] isKindOfClass:[NSString class]])
        {
            
            splitStrings = [(NSString*)[retrievedDataArray objectAtIndex:i] componentsSeparatedByString:@"|"];
        }
        
        //use question for the key to an array that contains tokens and values
        if(splitStrings.count>0)
        {
            questionRetrieved = [splitStrings objectAtIndex:0];
            [questionsAndTokensDict setObject:tokenAndValuesArray forKey:questionRetrieved];
        }
        
        
        //insert tokens and values into the dictionary
        for(int j = 1; j < splitStrings.count; j++)
        {
            NSMutableArray* currentArray;
            switch (j%3) {
                case 0:
                {
                    //No points array
                    currentArray = [tokenAndValuesArray objectAtIndex:2];
                    break;
                }
                case 1:
                {
                    //Token_description array
                    currentArray = [tokenAndValuesArray objectAtIndex:0];
                    break;
                }
                case 2:
                {
                    //Yes points array
                    currentArray = [tokenAndValuesArray objectAtIndex:1];
                    break;
                }
                default:
                    break;
            }
            
            [currentArray addObject:splitStrings[j]];
            
            
        }
    }
}



-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    
    if([[segue destinationViewController] isKindOfClass:[ViewController2 class]])
    {
        targetVC = [segue destinationViewController];
    }
}

- (NSString*) getAddressFromField
{
    //the address entered by user from the question textfield, which is identified by keyword "Address"
    //in "placeholder" variable of UITextField
    for (UIView *i in self.view.subviews)
    {
        if([i isKindOfClass:[UITextField class]])
        {
            NSRange stringQuestionRange = NSMakeRange(0, 7);
            if(([[(UITextField*)i placeholder] compare:@"Address" options:NSCaseInsensitiveSearch range:stringQuestionRange] == NSOrderedSame)
               &&   ([(UITextField*)i text].length > 0))
            {
                return  [(UITextField*)i text];
                
            }
        }
    }
    return nil;
}

- (IBAction)startButton:(id)sender {
    //retrieve questions from database
    [self prepareAndSendInformation:nil];
    
    //pass questions and  current tokens on to the next viewcontroller as this viewcontroller
    //will be deleted to conserve memory (along with its members).
    targetVC.myQuestionTokens = self.myQuestionTokens;
}
@end
