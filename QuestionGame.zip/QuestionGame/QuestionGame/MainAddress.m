//
//  MainAddress.m
//  QuestionGame
//
//  Created by Olawale Jaiyeola on 7/10/16.
//  Copyright © 2016 Olawale Jaiyeola. All rights reserved.
//

#import "MainAddress.h"

static NSString* mAddress = nil;

@implementation MainAddress

+(NSString*)defaultAddress
{
    return mAddress;
}

+(void)setDefaultAddress:(NSString*)newAddress
{
    if(mAddress != newAddress)
    {
        if(mAddress)
        {
            [mAddress release];
        }
        mAddress = [newAddress retain];
    }
}
+ (void)initialize
{
    if(!mAddress)
    {
        mAddress = @"http://localhost/~olawalejaiyeola/index6.php";
    }
}

@end