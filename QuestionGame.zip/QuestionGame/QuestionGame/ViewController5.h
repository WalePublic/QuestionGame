//
//  ViewController5.h
//  QuestionGame
//
//  Created by Olawale Jaiyeola on 7/8/16.
//  Copyright (c) 2016 Olawale Jaiyeola. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ViewController2;

@protocol ViewController2Delegate <NSObject>
-(void)addQuestionViewController:(ViewController2 *)controller didFinishEnteringItem:(NSString*)item;

-(void)addDictionaryViewController:(ViewController2 *)controller didFinishEnteringItem:(NSMutableDictionary*)item;

-(void)addQuestionAndTokenViewController:(ViewController2 *)controller didFinishEnteringItem:(NSMutableDictionary*)item;

@end


@interface ViewController5 : UIViewController
{
    UIViewController *targetVC;
    NSMutableDictionary* myQuestionTokens;
    NSMutableDictionary* questionsAndTokensDict;
    NSString* currentQuestion;
}

@property (nonatomic) id<ViewController2Delegate> delegate;
@property (retain, nonatomic) IBOutlet UITableView *textTableView;
@property (retain, strong) NSMutableDictionary* questionsAndTokensDict;
@property (nonatomic, strong) NSMutableDictionary* myQuestionTokens;

@property (nonatomic, strong) NSString* currentQuestion;


@end
